# -*- coding: utf-8 -*-

import numpy as np
from proj1_helpers import *
from implementations import *


################################################

# DATA PREPROCESSING #

################################################


def class_allocation(input_data, yb, ids):
    """ Split the original dataset in four groups according to the categorical variable PRI_jet_num. """
    
    # Getting dimensions of each group
    num_0 = 0
    num_1 = 0
    num_2 = 0
    num_3 = 0 
    for j in range(input_data.shape[0]):
        if input_data[j,22] == 0:
            num_0 = num_0 + 1
        elif input_data[j,22] == 1:
            num_1 = num_1 + 1
        elif input_data[j,22] == 2:
            num_2 = num_2 + 1
        elif input_data[j,22] == 3:
            num_3 = num_3 + 1

    # Initializing arrays for different PRI_jet_num
    size = (num_0, input_data.shape[1])
    jet_num_0 = np.zeros(size)
    ids_0 = np.zeros(num_0)
    y0 = np.zeros(num_0)

    size = (num_1, input_data.shape[1])
    jet_num_1 = np.zeros(size)
    ids_1 = np.zeros(num_1)
    y1 = np.zeros(num_1)
    
    size = (num_2, input_data.shape[1])
    jet_num_2 = np.zeros(size)
    ids_2 = np.zeros(num_2)
    y2 = np.zeros(num_2)
    
    size = (num_3, input_data.shape[1])
    jet_num_3 = np.zeros(size)
    ids_3 = np.zeros(num_3)
    y3 = np.zeros(num_3)
    
    # Allocating input_data to the different groups
    i_0, i_1, i_2, i_3 = 0, 0, 0, 0


    for i in range(input_data.shape[0]):
        if input_data[i,22] == 0:
            jet_num_0[i_0,:] = input_data[i,:]
            ids_0[i_0] = i
            y0[i_0] = yb[i]
            i_0 = i_0 + 1
            
        elif input_data[i,22] == 1:
            jet_num_1[i_1,:] = input_data[i,:]
            ids_1[i_1] = i
            y1[i_1] = yb[i]
            i_1 = i_1 + 1
            
        elif input_data[i,22] == 2:
            jet_num_2[i_2,:] = input_data[i,:]
            ids_2[i_2] = int(i)
            y2[i_2] = yb[i]
            i_2 = i_2 + 1
            
        elif input_data[i,22] == 3:
            jet_num_3[i_3,:] = input_data[i,:]
            ids_3[i_3] = int(i)
            y3[i_3] = yb[i]
            i_3 = i_3 + 1
            
    ids_0 = ids_0.astype(int)
    ids_1 = ids_1.astype(int)
    ids_2 = ids_2.astype(int)
    ids_3 = ids_3.astype(int)
    
    return jet_num_0, y0, ids_0, jet_num_1, y1, ids_1, jet_num_2, y2, ids_2, jet_num_3, y3, ids_3



def get_correlations(matrix, bound):
    """ Return the couples of features whose Pearson correlation is higher than bound. """
    
    high_corr = []
    cor_matrix = np.corrcoef(matrix.T)
    
    for i in range(cor_matrix.shape[0]):
        for j in range(i+1,cor_matrix.shape[1]):
            if cor_matrix[i,j] > bound:
                high_corr.append((i,j))
                
    return high_corr


################################################

# TRAINING #

################################################


def ridge_deg_lam(yb, data, kfolds, degree, lambda_):
    """ Build augmented features (polynomial basis with the chosen degree) and solve the Ridge 
        regression with the normal equations for lambda_, performing a k-fold cross validation 
        to compute RMSE, accuracy and weights. """
    
    rmse_train=[]
    rmse_test=[]
    seed = 3

    # Build indices to split data
    k_indices = build_k_indices(yb, kfolds, seed)

    rmse_tr_k = []
    rmse_te_k = []
    w_ridge_k = []
    accuracy_k = []
        
    # Build X matrix
    data1 = build_poly(data, degree)
    
    # Loop over the folds
    for k in range(kfolds):
        
        data_test, y_test, data_train, y_train = split_dataset(yb, data1, k, k_indices)   
        
        # Train the model
        w_k, mse_k = ridge_regression(y_train, data_train, lambda_)
        rmse_test = np.sqrt(2*compute_mse(y_test, data_test, w_k))
            
        # Do the prediction on the current test set and compute accuracy
        ypred = predict_labels(w_k, data_test)
        acc_k = compute_accuracy(ypred, y_test)
            
        # Store rmse, weights and accuracy
        rmse_tr_k.append(np.sqrt(2*mse_k))
        rmse_te_k.append(rmse_test)
        w_ridge_k.append(w_k)
        accuracy_k.append(acc_k)
        
    # Compute the means over the folds
    rmse_tr = np.mean(rmse_tr_k)
    rmse_te = np.mean(rmse_te_k)
    w_ridge = np.mean(w_ridge_k, axis=0)
    accuracy = np.mean(accuracy_k)
        

    return rmse_tr, rmse_te, w_ridge, accuracy


################################################

# TUNING HYPERPARAMETERS #

################################################


def grid_search_ridge(y, tx, kfolds, deg_grid, lam_grid):
    """ Perform a grid search over deg_grid and lam_grid to find the best parameters for the model trained on tx.
        Return the optimal lambda, the optimal degree and the optimal weights obtained with a kfolds cross validation
        (The index to evaluate and compare models is the accuracy). """
    
    losses = np.zeros((len(deg_grid),len(lam_grid)))
    accuracies = np.zeros((len(deg_grid),len(lam_grid)))
    acc_old = -1
    
    # Perform a grid search
    for i, deg in enumerate(deg_grid):
        for j, lam in enumerate(lam_grid):  
            
            rmse_train, rmse_test, w_ridge, acc = ridge_deg_lam(y, tx, kfolds, deg, lam)
            
            losses[i,j] = rmse_test
            accuracies[i,j] = acc
            
            if acc > acc_old:
                weight_opt = w_ridge
                deg_opt_acc = deg     
                lam_opt_acc = lam     
                max_accuracy = acc    
            
            acc_old = acc            
        
    # Get best parameters according to RMSE test.
    min_rmse_test, deg_opt_err, lam_opt_err = get_best_rmse(lambdas_grid, degree_grid, losses)  
    
    return min_rmse_test, deg_opt_err, lam_opt_err, max_accuracy, deg_opt_acc, lam_opt_acc, weight_opt