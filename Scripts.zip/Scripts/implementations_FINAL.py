# -*- coding: utf-8 -*-

import numpy as np
from proj1_helpers import *

################################################

# BASIC METHODS #

################################################


def least_squares(y, tx):
    """Compute the least squares solution by solving the normal equations."""
    
    transp=tx.T
    w = np.linalg.solve(transp@tx, transp@y)
    
    return w, compute_mse(y,tx,w)



def least_squares_GD(y, tx, initial_w, max_iters, gamma, tol=1e-4):
    """Compute the least squares solution by gradient descent method."""
    
    # Initializing parameters
    w_old = initial_w
    n_iter = 0
    err = 1
    
    # looping to max_iters or to the reached tolerance
    while n_iter < max_iters and err > tol:
        n_iter += 1
        grad = compute_gradient(y,tx,w_old)
   
        # update optimal set of parameters
        w_new = w_old - gamma*grad
        err = np.linalg.norm(w_new - w_old)
        w_old = w_new
        
    return w_new, compute_mse(y,tx,w_new)


    
def least_squares_SGD(y, tx, initial_w, max_iters, gamma, tol=1e-4):
    """Compute the least squares solution by stochastic gradient descent method."""
   
    # Initializing parameters
    w_old = initial_w
    n_iter = 0
    err = 1
    
    # Looping to max_iters or to the reached tolerance
    while n_iter < max_iters and err > tol:
        n_iter += 1
        
        # Use the standard minibatch_size = 1
        for miniy, minitx in batch_iter(y,tx,1):
            g = compute_gradient(miniy, minitx,w_old)
            
        w_new = w_old - gamma*g
        err = np.linalg.norm(w_new-w_old)
        w_old = w_new
    
    return w_new, compute_mse(y,tx,w_new)


    
def ridge_regression(y, tx, lambda_):
    """Compute the Ridge regression solution by solving the normal equations."""
    
    transp = tx.T
    m = transp@tx + 2*tx.shape[0]*lambda_*np.identity(tx.shape[1])
    w = np.linalg.solve(m, transp@y)
    
    return w, compute_mse(y,tx,w)


    
def logistic_regression(y, tx, initial_w, max_iters, gamma, tol=1e-8):
    """ Logistic regression using the GRADIENT DESCENT method
        the stopping criterium is the norm of the gradient"""
    
    # Initializing parameters
    w = initial_w
    err = 1
    niter = 0
    
    while niter < max_iters and err > tol:
        niter += 1
        
        # Compute loss, gradient
        loss = compute_logloss(y, tx, w)
        grad = compute_loggrad(y, tx, w)
        
        # Update
        w = w - gamma*grad
        
        # Check criterium      
        err = np.linalg.norm(grad)
        
        # Print output
        if niter % 50 == 0:
            print("Current iteration={i}, loss={l}, norm_grad = {g}".format(i=niter, l=loss, g = err))
        
    return w, loss
    
    
    
def reg_logistic_regression(y, tx, lambda_, initial_w, max_iters, gamma, tol = 1e-7):
    """ Regularized logistic regression using the GRADIENT DESCENT method
        the stopping criterium is the norm of the gradient"""
    
    # Initializing parameters
    w = initial_w
    err = 1
    niter = 0
    
    while niter < max_iters and err > tol:
        niter += 1
        
        # Compute loss, gradient
        loss = compute_logloss(y, tx, w) + 0.5*lambda_*(w.T@w)
        grad = compute_loggrad(y, tx, w) + lambda_*w
        
        # Update
        w = w - gamma*grad
        
        # Check criterium
        err = np.linalg.norm(grad)
        
        # Print output
        if niter % 50 == 0:
            print("Current iteration={i}, loss={l}, norm_w = {n}, norm_grad={ng}".format(i=niter, l=loss, n=np.sqrt(w.T@w), ng=err))
        
    return w, loss
    
    
    
################################################

# HELPER FUNCTIONS #

################################################            


def remove_useless_cols(matrix):
    """ Remove features with zero standard deviation from input matrix. """
    
    std_cols = np.std(matrix, axis=0)
    num_rem = 0
    for col in reversed(range(matrix.shape[1])):
        if std_cols[col] == 0:
            num_rem = num_rem + 1
         
    for col in reversed(range(matrix.shape[1])):
        if std_cols[col] == 0:
            matrix = np.delete(matrix,col,1)
            
    return matrix



def clean_data(matrix):
    """ Substitute the invalid values (-999) with the mean of the column. """
    
    cleansubx = matrix
    cleansubx[np.where(cleansubx == -999)] = 0
    means_by_columns = np.mean(cleansubx, axis=0)
    for i in range(matrix.shape[1]):
        matrix[:,np.where(matrix[:,i]==-999)] = means_by_columns[i]
    
    return matrix
    
    
    
def standardize(x):
    """ Standardize data according to the mean and std of each feature. """
    
    x = (x - np.mean(x,axis=0)) / np.std(x, axis=0)
    return x



def clean_and_standardize(matrix):
    
    matrix = clean_data(matrix)
    matrix = standardize(matrix)
    
    return matrix



def build_poly_col(x, degree):
    """ Polynomial basis functions for input column x, from j=1 up to j=degree. """
    
    y = x        
    for n in range(2,degree+1):
        x = np.c_[x, np.power(y,n)]
            
    return x



def build_poly(data, degree):
    """ Polynomial basis functions for input data. 
        Each features is treated with the same polynomial degree. """
    
    X = np.c_[np.ones(data.shape[0])]
    for j in range(data.shape[1]):
        x_col = build_poly_col(data[:,j], degree)
        X = np.c_[X, x_col]
        
    return X



def build_k_indices(y, k_fold, seed):
    """ Build random k indices for k-fold cross validation. """
    
    num_row = y.shape[0]
    interval = int(num_row / k_fold)
    np.random.seed(seed)
    indices = np.random.permutation(num_row)
    k_indices = [indices[k * interval: (k + 1) * interval]
                 for k in range(k_fold)]
    return np.array(k_indices)



def split_dataset(y, x, k, k_indices):
    """ Return matrices and vectors Test and Train used in a k-fold cross validation. """
    
    # Get k'th subgroup in test, others in train.
    X_test = x[k_indices[k]]
    y_test = y[k_indices[k]]
    X_train = np.delete(x,k_indices[k],0)
    y_train = np.delete(y,k_indices[k])
    
    return X_test, y_test, X_train, y_train



def compute_mse(y, tx, w):
    """ Compute the MSE cost function. """

    e = y - tx.dot(w)
    return 1/2*np.mean(e**2)



def compute_gradient(y, tx, w):
    """ Compute the gradient of MSE cost function. """
    
    e = y - tx.dot(w)
    
    grad = -tx.T.dot(e) / len(e)
    return grad

            
            
def get_best_rmse(lam, deg, losses):
    """ Get the best (lam, deg) from the result of grid search. """
 
    min_row, min_col = np.unravel_index(np.argmin(losses), losses.shape)
    return losses[min_row, min_col], deg[min_row], lam[min_col]



def compute_accuracy(ypred, yknown):
    """ Compute the accuracy of the prediction as n_exact_predictions/total. """
    
    nexact = np.sum(ypred == yknown)
    return nexact/len(yknown)



def batch_iter(y, tx, batch_size, num_batches=1, shuffle=True):
    """
    Generate a minibatch iterator for a dataset.
    Takes as input two iterables (here the output desired values 'y' and the input data 'tx')
    Outputs an iterator which gives mini-batches of `batch_size` matching elements from `y` and `tx`.
    Data can be randomly shuffled to avoid ordering in the original data messing with the randomness of the minibatches.
    Example of use :
    for minibatch_y, minibatch_tx in batch_iter(y, tx, 32):
        <DO-SOMETHING>
    """
    data_size = len(y)

    if shuffle:
        shuffle_indices = np.random.permutation(np.arange(data_size))
        shuffled_y = y[shuffle_indices]
        shuffled_tx = tx[shuffle_indices]
    else:
        shuffled_y = y
        shuffled_tx = tx
    for batch_num in range(num_batches):
        start_index = batch_num * batch_size
        end_index = min((batch_num + 1) * batch_size, data_size)
        if start_index != end_index:
            yield shuffled_y[start_index:end_index], shuffled_tx[start_index:end_index]
            

################################################

# LOGISTIC REGRESSION #

################################################


def sigmoid_scalar(t):
    """ Apply sigmoid function to t. """
    
    if t >= 0:
        return 1.0 / (1.0 + np.exp(-t))
    else:
        return np.exp(t) / (1 + np.exp(t))
    
sigmoid = np.vectorize(sigmoid_scalar)



def compute_logloss(y, tx, w):
    """ Compute the loss function in the logistic regression as
        the negative log likelihood. """
    
    one = np.ones(len(y))
    first = (np.log(1 + np.exp(tx@w))) @ one

    second = y @ (tx@w)
    
    return first-second



def compute_loggrad(y, tx, w):
    """ Compute the gradient of logistic loss function. """
    
    sig = sigmoid(tx@w)
    return tx.T @ (sig - y)



def compute_hessian(y, tx, w):
    """ Compute the Hessian matrix of the logistic loss function.
    (with this implementation the computational cost in terms of time and memory 
    can be very high, since we build a NxN matrix)."""
   
    sig = np.squeeze(sigmoid(tx@w))
    
    S = np.diag(sig - sig*sig)
    SX = S@tx
    
    return tx.T @ SX



def logistic_newton(y, tx, initial_w, max_iters, gamma, tol=1e-8):
    """ Logistic regression using NEWTON's method.
        The stopping criterium is the abs of the difference of two successive losses"""
    
    # Initializing parameters
    w = initial_w
    err = 1
    niter = 0
    
    while niter < max_iters and err > tol:
        niter += 1
        
        # Compute loss, gradient
        loss = compute_logloss(y, tx, w)
        grad = compute_loggrad(y, tx, w)
        hess = compute_hessian(y, tx, w)
      
        # Update with Newton
        v = np.linalg.solve(hess,grad)
        w = w - gamma*v
        
        # Check criterium
        err = np.linalg.norm(grad)        
            
        # Print output
        if niter % 50 == 0:
            print("Current iteration={i}, loss={l}, norm_grad = {g}".format(i=niter, l=loss, g=err))
        
    return w, loss



def reg_logistic_newton(y, tx, lambda_, initial_w, max_iters, gamma, tol = 1e-8):
    """ Regularized logistic regression using NEWTON's method.
        The stopping criterium is the abs of the difference of two successive losses"""
    
    # Initializing parameters
    w = initial_w
    err = 1
    niter = 0
    
    while niter < max_iters and err > tol:
        niter += 1
        
        # Compute loss, gradient
        loss = compute_logloss(y, tx, w) + 0.5*lambda_*(w.T@w)
        grad = compute_loggrad(y, tx, w) + lambda_*w
        hess = compute_hessian(y, tx, w) + np.diag(lambda_*np.ones(len(w)))
      
        # Update with Newton
        v = np.linalg.solve(hess,grad)
        w = w - gamma*v
        
        # Check criterium
        err = np.linalg.norm(grad)  
            
        # Print output
        if niter % 50 == 0:
            print("Current iteration={i}, loss={l}, norm_grad = {g}".format(i=niter, l=loss, g=err))
        
    return w, loss
