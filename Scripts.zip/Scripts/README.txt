*********************************   README   *********************************
******************** ML PROJECT 1 2018-2019 - HIGGS BOSON ********************

Alessandra Arrigoni
Emiljiano Gjiriti
Paul Münnich

This folder contains the code to reproduce our best result in the Kaggle competition using the dataset about Higgs Boson provided by CERN.

The executable is named run.py and it is compatible with Python 3.6.5:
- to load the datasets ('train.csv' and 'test.csv') they have to be in a directory called 'datasets' contained in the same folder of the executable.
- the output with the final predictions is a csv file named 'submission.csv' (????????????) contained in the same directory of the executable.

The only needed libraries are NumPy (1.14.3) and matplotlib.pyplot, used to produce the plots.

**************************

The file 'proj1_helpers.py' contains some helper functions used to load the datasets, to make the predictions and to create the output csv file.

**************************

The file 'implementations.py' contains all the basic functions used in the project, and it is structured with the following sections:

BASIC METHODS
- least_squares(): least squares regression using normal equations and MSE cost function.
- least_squares_GD(): least squares regression using gradient descent iterative method and MSE cost function; defaulted parameter: tolerance for the stopping criterium.
- least_squares_SGD(): least squares regression using stochastic gradient descent method and MSE cost function; defaulted parameter: tolerance for the stopping criterium.
- ridge_regression(): ridge regression using normal equations and MSE cost function.
- logistic_regression(): logistic regression using gradient descent ierative method; defaulted parameter: tolerance for the stopping criterium.
- reg_logistic_regression(): logistic regression using the regularization term and gradient descent iterative method; defaulted parameter: tolerance for the stopping criterium.

HELPER FUNCTIONS:
- remove_useless_cols(): treatment of non measured features.
- clean_data(): treatment of invalid values (-999).
- standardize(): data standardization according to mean and standard deviation.
- build_poly_col() and build_poly(): creation of augmented features with a polynomial basis.
- build_k_indices() and split_dataset(): splitting of the training set to perform cross validation. 
- compute_mse(): compute MSE cost function.
- compute_gradient(): gradient of MSE cost function.
- get_best_rmse(): finds the optimal hyperparameters for the ridge regression (lambda and polynomial degree) in the grid search, according to the minimum rmse.
- compute_accuracy(): computes the accuracy of a prediction on the test set.
- batch_iter()

LOGISTIC REGRESSION: 
- sigmoid_scalar() and sigmoid(): sigmoid function for a scalar and for a vector (elementwise) respectively.
- compute_logloss(): negative log likelihood associated to the conjoint Bernoulli distrubution.
- compute_loggrad(): gradient of the logistic regression loss function.
- compute_hessian(): Hessian matrix of the logistic regression loss function.
- logistic_newton(): logistic regression using Newton's iterative method; defaulted parameter: tolerance for the stopping criterium.
- reg_logistic_newton(): logistic regression using the regularization term and Newton's iterative method; defaulted parameter: tolerance for the stopping criterium.

**************************

The file 'methods.py' contains all the methods used during the phases of preprocessing, training, and tuning the hyperparameters; it is structured with the following sections:

DATA PREPROCESSING
- class_allocation(): splitting of the dataset into four groups according to the categorical variable PRI_jet_num.
- get_correlations(): selection of the highly linearly correlated features.

TRAINING
- ridge_deg_lam(): Ridge regression with the augmented features (polynomial basis) and computation of the indices to evaluate the model.

TUNING HYPERPARAMETERS
- grid_search_ridge(): grid search to find the best hyperparameters (lambda and degree) for the Ridge regression according to the accuracy on the test set within a kfolds cross validation. 

